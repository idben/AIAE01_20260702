# 潛水證照筆試放榜！分數 >= 60 算「合格」，否則「不合格」
# 用 if-else 做雙向判斷
score1 = 85
score2 = 40

# TODO：分別判斷 score1、score2 是否通過筆試
#       合格存字串 "合格"，不合格存 "不合格"
#       還沒學函式，請對兩個分數各寫一次 if-else
result1 = ""
result2 = ""
