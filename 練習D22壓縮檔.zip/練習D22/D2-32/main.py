# 🅿️ 停車場有 3 排，每排 8 個車位，用巢狀 for 數數看總共幾個車位
count = 0

# TODO：外層 for 跑 range(3)（排），內層 for 跑 range(8)（每排車位）
#       每數到一個車位就把 count 加 1
