# 遊戲擂台開打！我方戰力 10，對手戰力 5。
# 關係運算子的結果是布林值（True 或 False），可以直接存起來
my_power = 10
enemy_power = 5

# TODO：用關係運算子算出下面各題（都存布林值）
#       tie：雙方實力是否「打平」（my_power 等於 enemy_power，用 ==）
#       different：雙方實力是否「不同」（用 !=）
#       reach_goal：我方是否達到過關門檻 10（my_power 大於等於 10，用 >=）
#       am_weaker：我方是否「比較弱」（my_power 小於 enemy_power，用 <）
#       name_order：排行榜上 "Anna" 是否排在 "Bella" 前面（字典順序，用 <）
tie = None
different = None
reach_goal = None
am_weaker = None
name_order = None
