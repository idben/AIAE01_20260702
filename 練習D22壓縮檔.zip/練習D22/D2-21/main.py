# 🛒 購物車裡有幾樣商品的價格，結帳要把它們全部加起來
prices = [120, 80, 45, 200]
total = 0

# TODO：用 for 迴圈走訪 prices，把每個價格加進 total，算出結帳金額
