# 🪑 教室座位有 4 列 5 欄，每個座位的號碼 = 列號 × 欄號（列、欄都從 1 開始）
# 用巢狀 for 把所有座位號碼加起來
total = 0

# TODO：外層 for r 跑 range(1, 5)（列），內層 for c 跑 range(1, 6)（欄）
#       把每個 r * c 加進 total
