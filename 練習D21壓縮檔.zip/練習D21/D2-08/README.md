# D2-08 練習：週末露營計畫（and、or、not）

## 題目

週末想去露營，用邏輯運算子做三個判斷：

- `can_go`：只要「週末或連假」就能出遊（`is_weekend or is_holiday`）
- `can_drive`：要「年滿 `18` 且有駕照」才能開車去（`age >= 18` 且 `has_license`）
- `need_backup`：天氣「不是」晴天就要準備備案（用 `not` 反轉 `is_sunny`）

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `and`：兩邊都為真才是 `True`
- `or`：其中一邊為真就是 `True`
- `not`：把 `True` 變 `False`、`False` 變 `True`
- `has_license` 本身就是布林值，直接用即可，不用再寫 `== True`

## 這題常見錯誤

- 把 `and` 與 `or` 用反
- 這三個變數要存布林值

## 這題在測什麼

- 是否會用 `and`、`or`、`not` 組合條件
