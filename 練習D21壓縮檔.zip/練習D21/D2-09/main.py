# 網站註冊表單送出了！系統要判斷每個欄位「在 if 裡算不算有填」
# 用 bool() 可以看出一個值在條件判斷裡算 True 還是 False
# 陷阱：只要字串「不是空的」就是 True，即使內容是 "0"、"False" 或只有一個空白

# TODO：用 bool() 算出下面各欄位的真假（先自己猜，再跑 test）
#       qty_filled：數量欄填了 0        → bool(0)
#       msg_filled：留言欄整個留空       → bool("")
#       code_filled：驗證碼欄填了 "0"    → bool("0")
#       note_filled：備註欄填了 "False"  → bool("False")
#       nick_filled：暱稱欄只打了一個空白 → bool(" ")
qty_filled = None
msg_filled = None
code_filled = None
note_filled = None
nick_filled = None
