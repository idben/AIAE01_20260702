# 🍊 大家排成一排，用 enumerate 找出 "橘子" 排在第幾位（索引從 0 算）
fruits = ["蘋果", "香蕉", "橘子", "西瓜"]
target_index = -1

# TODO：用 for 搭配 enumerate 走訪 fruits，找到 "橘子" 時把它的索引存進 target_index
#       （-1 代表還沒找到）
