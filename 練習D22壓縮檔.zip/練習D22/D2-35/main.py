# 🤖 保全機器人巡邏 5 間房，每間都從第 0 號櫃子開始檢查
# 但查到「第 2 號櫃子」（index 2）就換下一間（內層 break）
# 用巢狀 for 數數看總共檢查了幾個櫃子
count = 0

# TODO：外層 for room 跑 range(5)（房間），內層 for locker 跑 range(5)（櫃子）
#       一遇到 locker == 2 就 break 換下一間；否則把 count 加 1
