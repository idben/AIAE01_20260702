# 週末露營計畫！用邏輯運算子判斷幾件事：and（且）、or（或）、not（非）
is_weekend = True       # 今天是週末
is_holiday = False      # 今天不是國定假日
age = 20                # 你的年齡
has_license = True       # 有沒有駕照
is_sunny = False        # 天氣是不是晴天

# TODO：算出下面三個判斷（都存布林值）
#       can_go：只要「週末或連假」就能出遊（用 or）
#       can_drive：要「年滿 18 且有駕照」才能開車去（age >= 18 且 has_license，用 and）
#       need_backup：天氣「不是」晴天就要準備備案（用 not）
can_go = None
can_drive = None
need_backup = None
