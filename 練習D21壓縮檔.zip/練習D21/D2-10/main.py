# 社團小編審貼文！成員運算子：in（在裡面）、not in（不在裡面），結果是布林值
post = "快來看 http://sale.com 限時折扣"
guest_list = ["Amy", "Bob", "Cathy"]

# TODO：
#       has_link：貼文 post 裡是否「夾了網址」（檢查有沒有 "http"，用 in）
#       not_invited：訪客 "Tom" 是否「不在」賓客名單 guest_list 裡（用 not in）
has_link = None
not_invited = None
