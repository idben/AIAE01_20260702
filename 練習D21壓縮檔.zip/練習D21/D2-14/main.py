# 自動駕駛的攝影機讀到燈號，車子要決定怎麼開
# 用 if-elif-else 對應多種燈號，else 負責處理「讀到怪東西」的非預期情形
light1 = "green"
light2 = "purple"

# TODO：依攝影機讀到的燈號決定動作
#       "red" 存 "停止"，"green" 存 "通行"，"yellow" 存 "減速"，其它一律存 "警告：無效的燈號"
#       light1 的結果存進 action1，light2 的結果存進 action2
action1 = ""
action2 = ""
