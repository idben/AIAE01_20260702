# 🏢 大樓 1 到 10 樓，偶數樓先跳過（用 pass 佔位，之後再處理）
# 只把「奇數樓層」的號碼加起來
total = 0

# TODO：用 for 跑 range(1, 11)，偶數樓（f % 2 == 0）先用 pass 佔位，
#       else 把奇數樓號加進 total
