# 📟 感測器記錄了一串讀數，找出「第一個」超過 100 的爆表值就停手
readings = [45, 78, 99, 120, 60, 150]
first_over = 0

# TODO：用 for 走訪 readings，遇到第一個大於 100 的值就存進 first_over，
#       並用 break 立刻跳出（後面的不用再看）
