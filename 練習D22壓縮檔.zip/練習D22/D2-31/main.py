# ✖️ 把九九乘法表（1×1 到 9×9）每一格的乘積全部加起來
# 用巢狀 for：外層 i、內層 j，累加 i × j
total = 0

# TODO：外層 for i 跑 range(1, 10)，內層 for j 跑 range(1, 10)
#       把每個 i * j 加進 total
