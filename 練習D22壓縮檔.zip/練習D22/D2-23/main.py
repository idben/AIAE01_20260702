# 📝 這是一位學生的小考成績，把三科分數全部加起來算總分
scores = {"國文": 80, "英文": 75, "數學": 90}
total = 0

# TODO：用 for 迴圈走訪 scores 的「值」（scores.values()），把每科分數加進 total
