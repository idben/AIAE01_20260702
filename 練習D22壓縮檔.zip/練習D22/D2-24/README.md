# D2-24 練習：排隊第幾位（enumerate 找索引）

## 題目

清單 `fruits = ["蘋果", "香蕉", "橘子", "西瓜"]`。
用 `enumerate` 同時取得索引與水果，找出 `"橘子"` 的索引存進 `target_index`（索引從 `0` 算）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for index, fruit in enumerate(fruits)` 可同時拿到索引與值
- 找到就把 `index` 存起來

## 這題常見錯誤

- 忘了 `enumerate` 會回傳「索引, 值」兩個東西
- 把值當索引存

## 這題在測什麼

- 是否會用 `enumerate` 同時取得索引與值
