# D2-05 練習：備份會不會跟著變？（原地更新）

## 題目

帳戶餘額 `balance` 是 `1000`，你先把它「記下」當作備份（`backup = balance`）。
之後帳戶又存入 `500`，請用 `+=` 更新 `balance`。接著回答：`backup` 有沒有跟著變？

1. 用 `+=` 把 `balance` 加 `500`（`balance` 最後應該是 `1500`）
2. 判斷「`backup` 有沒有跟著變成 `1500`」，把答案存進 `backup_changed`（`True` 或 `False`）

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `balance += 500` 只會更新 `balance`
- `backup` 早就存了自己的值 `1000`，不會因為 `balance` 改變而跟著變
- 所以「`backup` 有沒有跟著變成 `1500`」的答案是布林值，存 `True` 或 `False`

## 這題常見錯誤

- 以為 `backup = balance` 之後兩者會「連動」（對數字來說並不會）
- `backup_changed` 要存布林值 `True` 或 `False`，不要存數字或文字

## 這題在測什麼

- 是否理解複合指派只更新自己那個變數
- 備份 `backup` 是否維持原值
- 是否能把觀察到的結果，用布林值明確表達出來
