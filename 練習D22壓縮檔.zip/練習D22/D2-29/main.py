# 💳 這是一天的交易紀錄，正數是收入、負數是退款
# 用 continue 跳過退款，只把「正數收入」加起來
records = [200, -50, 150, -30, 80]
income = 0

# TODO：用 for 走訪 records，遇到負數（money < 0）就 continue 跳過，
#       其餘的加進 income，算出當日淨收入
