# 💰 你每天存 50 元，想存到 200 元（含）以上
# 用 while 一天一天存，數數看要幾天才達標
saved = 0
days = 0

# TODO：用 while 迴圈，只要 saved 還沒到 200 就繼續：
#       每一輪把 saved 加 50、days 加 1，算出總共要幾天
