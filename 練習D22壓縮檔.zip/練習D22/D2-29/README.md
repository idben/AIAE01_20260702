# D2-29 練習：當日淨收入（for + continue）

## 題目

交易紀錄 `records = [200, -50, 150, -30, 80]`，負數是退款。
用 `continue` 跳過退款，只把正數收入加進 `income`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 遇到負數就 `continue`，跳過本次剩下的程式
- `continue` 之後的累加只會處理到正數

## 這題常見錯誤

- 把退款（負數）也加進去，結果變小
- 用 `break` 而不是 `continue`，遇到第一筆退款就停了

## 這題在測什麼

- 是否分得清 `continue`（跳過本次）與 `break`（整個停止）
