# 電影院售票口！用巢狀 if 處理「先看是不是會員，再看年齡」的優惠
#   非會員 → 330；會員且年滿 60（敬老）→ 150；會員但未滿 60 → 250
is_member1 = True
age1 = 65
is_member2 = False
age2 = 30

# TODO：算出兩位客人的票價，存進 price1、price2
#       用巢狀 if：外層判斷是不是會員，內層再判斷年齡
price1 = 0
price2 = 0
