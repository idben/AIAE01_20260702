# 🍌 數數看 "banana" 這個字裡面有幾個 "a"
word = "banana"
count = 0

# TODO：用 for 迴圈走訪 word 的每個字元，遇到 "a" 就把 count 加 1
