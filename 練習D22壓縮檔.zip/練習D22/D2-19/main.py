# 📸 5 位貴賓排成一排照相，總共有幾種排法？
# 這就是「5 的階乘」：5 × 4 × 3 × 2 × 1，用 for 一路連乘
arrangements = 1

# TODO：用 for 迴圈跑 range(1, 6)，把 1 到 5 每個數字乘進 arrangements
#       算出總共有幾種排法
