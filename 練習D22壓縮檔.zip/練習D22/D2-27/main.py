# 🦠 病毒數量從 1 開始，每過一輪就變成 2 倍
# 用 while True 一直翻倍，直到數量「超過」1000 就停，記下經過幾輪
num = 1
rounds = 0

# TODO：用 while True 無窮迴圈，每一輪把 num 乘以 2、rounds 加 1
#       一旦 num 超過 1000（num > 1000）就用 break 跳出，算出經過幾輪
