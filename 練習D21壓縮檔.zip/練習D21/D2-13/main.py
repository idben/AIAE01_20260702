# 期末專題成績結算！用 if-elif-else 把分數換成等第。評分標準：
#   90 以上 A，80 到 89 B，70 到 79 C，60 到 69 D，未滿 60 F
score_a = 85
score_b = 50

# TODO：分別算出 score_a、score_b 的等第，存進 grade_a、grade_b
#       由高分往低分依序判斷，兩個分數各寫一次 if-elif-else
grade_a = ""
grade_b = ""
