# 遊樂園「大怒神」規定：身高要 120 公分（含）以上、未滿 195 公分才能搭
# Python 可以像數學一樣連著寫比較：120 <= 身高 < 195
height1 = 150
height2 = 210

# TODO：用連鎖比較判斷身高能不能搭「大怒神」（120 <= 身高 < 195）
#       height1 的結果存進 can_ride1，height2 的結果存進 can_ride2
can_ride1 = None
can_ride2 = None
