# D2-25 練習：訂單總額（zip 配對相乘）

## 題目

單價 `unit_prices = [15, 10, 45]`、數量 `quantities = [3, 2, 1]`。
用 `zip` 把單價與數量配成對，逐樣算「單價 × 數量」並加進 `total`，得出訂單總額。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for price, qty in zip(unit_prices, quantities)` 會一次拿到一組單價與數量
- 每組先相乘再累加

## 這題常見錯誤

- 忘了 `zip` 要一次接兩個變數
- 只把單價相加，漏了乘數量

## 這題在測什麼

- 是否會用 `zip` 同時走訪兩個序列
