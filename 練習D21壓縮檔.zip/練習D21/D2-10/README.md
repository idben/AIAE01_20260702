# D2-10 練習：社團貼文審核（成員運算子 in／not in）

## 題目

社團小編要審核貼文與進場名單：

- `has_link`：貼文 `post`（`"快來看 http://sale.com 限時折扣"`）裡是否「夾了網址」（檢查有沒有 `"http"`，用 `in`）
- `not_invited`：訪客 `"Tom"` 是否「不在」賓客名單 `guest_list` 裡（用 `not in`）

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `"http" in post` 檢查字串裡有沒有這段文字
- `"Tom" not in guest_list` 檢查值有沒有在清單裡，不在就是 `True`

## 這題常見錯誤

- 把 `in` 與 `not in` 用反
- 這兩個變數要存布林值

## 這題在測什麼

- 是否會用 `in`、`not in` 做成員判斷
