# 🧾 一張訂單有三樣商品，unit_prices 是單價、quantities 是數量
# 用 zip 把「單價」與「數量」配成對，算出訂單總金額
unit_prices = [15, 10, 45]
quantities = [3, 2, 1]
total = 0

# TODO：用 for 搭配 zip 同時走訪 unit_prices 與 quantities
#       把每樣商品的「單價 × 數量」加進 total
