# 帳戶餘額是 1000 元。你先「記下」目前的餘額當作備份（backup = balance）
# 之後帳戶又存入 500 元
balance = 1000
backup = balance

# TODO：
#   1. 用 += 把 balance 加 500（存款）
#   2. backup 有沒有「跟著」變成 1500？把答案存進 backup_changed（True 或 False）
backup_changed = None
